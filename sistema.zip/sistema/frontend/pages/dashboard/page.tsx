import React from 'react';
import { SistemaDashboard } from '../components/SistemaDashboard';

export default function SistemaDashboardPage() {
  return (
    <div>
      <SistemaDashboard />
    </div>
  );
}